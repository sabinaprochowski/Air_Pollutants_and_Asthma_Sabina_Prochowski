Finds the Mean Median and Mode of numeric columns. It is hard coded to only deal with columns in the csv that are numeric. I can quickly change it if I need to analyze different columns which is hy I put it in the private static final on the top.

I realized after doing this in MapReduce that Hive was a much easier way of doing it and will likely be doing that instead moving forward.